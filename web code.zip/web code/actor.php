<html>
<head>
<title>Actor</title>
<style> 
input[type=text]{
  width: 25%;
  padding: 10px 10px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
input[type=email]{
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
input[type=phone]{
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
select {
  width: 10%;
  padding: 12px 20px;
  border: none;
  margin: 8px 0;
  border-radius: 1px;
  background-color: ;
}
input[type=button], input[type=submit], input[type=reset] ,input[type=button]{
  background-color: #817F7F;
  border: none;
  color: black;
  padding: 16px 32px;
  text-decoration: none;
  margin: 2px 1px;
  cursor: pointer;
}
.button {
  background-color:#8e95a5;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>

</head>
<h1><marquee bgcolor="sky blue"> MOVIE DATABASE SYSTEM</marquee></h1>


<body style="background-color:#8e95a5;">
<font size="6"><h2>Actor</h2></font>
<script>
	var i = 0;
	var images = [];
	var time = 2000;
    images[0] = '116.jpg';
	images[1] = '122.jpg';
	images[2] = '125.jpg';
	 images[3] = '129.jpg';
	  images[4] = '124.jpg';
	   images[5] = '127.jpg'; 
	    images[6]='123.jpg';
		 images[7] = '117.jpg';
		  images[8] = '118.jpg';
		   images[9] = '119.jpg';
		    images[10] = '120.jpg';
			 images[11] = '121.jpg';
			  images[12] = '126.jpg';
	function changeImg(){
		document.slide.src = images[i];

		if(i < images.length - 1){
			i++;
		} else {
			i = 0;
		}

		setTimeout("changeImg()", time);
	}

	window.onload = changeImg;

</script>

<center><img name="slide" width="1550" height="660"></center>
<br><br>
<form action="actor1.php" method="POST"><font size="5">

<b>Actor Name:<input name="Actor_name" type="text" value="" placeholder="Actor_Name"  size="35" ></td>
<br><br>
Actor_id:<input name="Actor_id" type="text" value=""placeholder="Actor_id"><br>
<br>
Gender:  male   <input type="radio"name="gender" value="male">
         Female <input type="radio"name="gender" value="female">
<br><br>
Actor_Email:<input name="Actor_email" type="email" value="" placeholder="Actor_Email"><br>
<br>
Actor_phone:<select name="phone_code">
<option selected hidden value="">select code  </option>
<option value="+91">+91</option>
<option value="+92">+92</option>
<option value="+93">+93</option>
<option value="+94">+94</option>
</select>

<input name="Actor_phone" type="phone" placeholder="Actor_phone" maxlength="10" size="20"><br>
 
<br><input type="submit" value="submit">
<input type="Reset" value="Reset">
<button class="button"><a href ="home.php">Home</a></button>
 </font>
 
</body>
</html>