<html>
<head>
<title>Navigation bar and menus with search box</title>
<style>
   body{
         background:#8e95a5;
         margin:0;
}
.menu{
     	width:100%;
     	background:#142b47;
	overflow:auto;
}
.menu ul{
	margin:0;
	padding:0;
	list-style:none;
	line-height:60px;
}
.menu li{
	float:left;
	}
.menu ul li a{
  	background:#142B47;
	text-decoration:none;
	width:130px;
	display:block;
	text-align:center;
	color:#f2f2f2;
	font-size:18px;
	font-family:sans_serif;
	letter-spacing:0.5px;
}
.menu li a:hover {
	color:#fff;
	opacity:0.5;
	font-size:19px;
}
.search-form{
	margin-top:15px;
	float:right;
	margin_right:100Px;
}
input[type=text]{
	padding:7px;
	border:none;
	font-size:16px;
	font-family:sans_serif;
}
button{
 	float:right;
	background:orange;
	color:white;
	border-radius:0 3px 3px 0;
	cursor:pointer;
	position:relative;
	padding:7px;
	font-family:sans-serif;
	boarder:none;
	font-size:16px;
}

</style> 
</head>
<body>
<nav class="menu">
<ul>
    <li><a href ="home.php">Home</a></li>
    <li><a href ="actor.php">Actor</a></li>
    <li><a href ="director.php">Director</a></li>
    <li><a href ="movie.php">movie</a></li>
    <li><a href ="feedback.php">feedback</a></li>
     <li><a href ="gellary.html">Gallery</a></li>
    <li><a href ="about.html">about</a></li>
	<li><a href ="DataBase.php">DataBase</a></li>
     
    </ul>
<form class ="search-form">
      <input type="text" placeholder="Search">
<button><a href ="https://www.google.com/">Search
</button></a>

</nav>
<h1><marquee bgcolor="sky blue"> MOVIE MANAGMENT SYSTEM
</marquee></h1>
<center>
<video width="1700" height="670" autoplay>
  <source src="homevideo.mkv" type="video/mp4"></video>
</center>
</body>

</html>

