<html>
<head>
 <title>Table with database</title>
 <style>
  table {
   border-collapse: collapse;
   width: 50%;
   color: #588c7e;
   font-family: monospace;
   font-size: 15px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
 </style>
</head>
<?php
if($_SERVER['REQUEST_METHOD']==='POST'){

$Actor_Name=$_POST["Actor_name"];
$Actor_id=$_POST["Actor_id"];
$Gender=$_POST["gender"];
$Actor_Email=$_POST["Actor_email"];
$phone_code=$_POST["phone_code"];
$Actor_phone=$_POST["Actor_phone"];

$servername="localhost";
$username="root";
$password="";
$dbname="soma";

$conn = new mysqli ($servername,$username,$password,$dbname); 
if ($conn->connect_error){
die("connection failed,$conn->connect_error");
}
echo "";


$sql="INSERT INTO krs(Actor_name,Actor_id,gender,Actor_email, phone_code,Actor_phone) VALUES('$Actor_Name','$Actor_id','$Gender','$Actor_Email','$phone_code','$Actor_phone')";
if($conn->query($sql)===TRUE){
echo  " ";
}else{
echo "Error:" ,$sql,"<br>",$conn->error;
}
$sql = "SELECT  Actor_Name,Actor_id,Gender,Actor_Email,phone_code,Actor_phone FROM  krs";
     $result = ($conn->query($sql));
	 if ($result->num_rows > 0)
	 {
		 echo "<table>";
		 while($row = $result->fetch_assoc()){
			 echo "<tr><td> Actor_Name: " .$row["Actor_Name"]."</td><td> Actor_id: ".$row["Actor_id"]."</td> <td> Gender: ".$row["Gender"]."</td><td> Actor_Email: ".$row["Actor_Email"]."</td><td> phone_code: ".$row["phone_code"]."</td><td> Actor_phone: ".$row["Actor_phone"]."</td></tr>";
			
		 }			
		 echo "</table>";
		 }else{
			 echo " 0 results";
		      }
		 
	 }
$conn->close();
?>
</html>