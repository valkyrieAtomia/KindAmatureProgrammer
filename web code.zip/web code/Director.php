<html>
<head>
<title>Director</title>
<style> 
input[type=text]{
  width: 25%;
  padding: 10px 10px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
input[type=email]{
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
input[type=phone]{
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
select {
  width: 10%;
  padding: 12px 20px;
  border: none;
  margin: 8px 0;
  border-radius: 1px;
  background-color: ;
}
input[type=button], input[type=submit], input[type=reset] ,input[type=button]{
  background-color: #817F7F;
  border: none;
  color: black;
  padding: 16px 32px;
  text-decoration: none;
  margin: 2px 1px;
  cursor: pointer;
}
.button {
  background-color: #8e95a5;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>
<h1><marquee bgcolor="sky blue">MOVIE DATABASE SYSTEM</marquee></h1>
<font size="6"><h2>Director</h2></font>
<script>
	var i = 0;
	var images = [];
	var time = 2000;
    images[0] = '130.jpg';
	images[1] = '131.jpg';
	images[2] = '132.jpg';
	 images[3] = '133.jpg';
	  images[4] = '134.jpg';
	   images[5] = '135.jpg'; 
	    images[6]='136.jpg';
		 
	function changeImg(){
		document.slide.src = images[i];

		if(i < images.length - 1){
			i++;
		} else {
			i = 0;
		}

		setTimeout("changeImg()", time);
	}

	window.onload = changeImg;

</script>

<center><img name="slide" width="1550" height="660"></center>
<br><br>

<body style="background-color:#8e95a5 ;">
<br>
<br><br><font size="5">
<form action="Director1.php" method="POST">
<b>Director Name:<input name="Director Name" type="text" value="" placeholder="Director_Name">
<br>
<br>
Director_id:<input name="Director_id" type="text" value="" placeholder="Director_id"><br>
<br>
 Gender: male<input type="radio"name="gender" value="male">
         Female<input type="radio"name="gender" value="Female">
<br><br>
Director_Email:<input name="Director_Email" type="Email" value=""placeholder="Email"><br>
<br>
 
</select>
Director_phone:<select name="phone_code">
<option selected hidden value="">select code  </option>
<option value="+91">+91</option>
<option value="+92">+92</option>
<option value="+93">+93</option>
<option value="+94">+94</option>
</select> <input  name="Director_phone" type="phone"  value="" placeholder="phone no"><br>
 
<br><input type="submit" value="submit">
<input type="Reset" value="Reset">
<button class="button"><a href ="home.php">Home</a></button>
  </font>
</html>
