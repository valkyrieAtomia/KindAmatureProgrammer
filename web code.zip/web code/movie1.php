<html>
<head>
 <title>Table with database</title>
 <style>
  table {
   border-collapse: collapse;
   width: 50%;
   color: #588c7e;
   font-family: monospace;
   font-size: 15px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
 </style>
</head>
<?php
if($_SERVER['REQUEST_METHOD']==='POST'){

$Movie_title=$_POST["Movie_title"];
$Movie_id=$_POST["Movie_id"];
$Release_Date=$_POST["Release_Date"];
$Movie_language=$_POST["Movie_language"];


$servername="localhost";
$username="root";
$password="";
$dbname="soma";

$conn = new mysqli ($servername,$username,$password,$dbname); 
if ($conn->connect_error){
die("connection failed,$conn->connect_error");
}
echo " ";


$sql="INSERT INTO movie(Movie_title,Movie_id,Release_Date,Movie_language) VALUES('$Movie_title','$Movie_id','$Release_Date','$Movie_language')";
if($conn->query($sql)===TRUE){
echo  " ";
}else{
echo "Error:" ,$sql,"<br>",$conn->error;
}
$sql = "SELECT  Movie_title,Movie_id,Release_Date,Movie_language FROM  movie";
     $result = ($conn->query($sql));
	 if ($result->num_rows > 0)
	 {
		 echo "<table>";
		 while($row = $result->fetch_assoc()){
			 echo "<tr><td>Movie_title: " .$row["Movie_title"]."</td><td> Movie_id: ".$row["Movie_id"]."</td> <td> Release_Date: ".$row["Release_Date"]."</td><td> Movie_language: ".$row["Movie_language"]."</td></tr>";
			
		 }			
		 echo "</table>";
		 }else{
			 echo " 0 results";
		      }
		 
	 }
$conn->close();

?>
</html>