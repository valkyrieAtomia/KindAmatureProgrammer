<html>
<head>
 <title>Table with database</title>
 <style>
  table {
   border-collapse: collapse;
   width: 50%;
   color: #588c7e;
   font-family: monospace;
   font-size: 15px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
 </style>
</head>
<?php
if($_SERVER['REQUEST_METHOD']==='POST'){

$Director_Name=$_POST["Director_Name"];
$Director_id=$_POST["Director_id"];
$Gender=$_POST["gender"];
$Director_Email=$_POST["Director_Email"];
$phone_code=$_POST["phone_code"];
$Director_phone=$_POST["Director_phone"];

$servername="localhost";
$username="root";
$password="";
$dbname="soma";

$conn = new mysqli ($servername,$username,$password,$dbname); 
if ($conn->connect_error){
die("connection failed,$conn->connect_error");
}
echo " ";


$sql="INSERT INTO krss(Director_name,Director_id,gender,Director_Email,phone_code,Director_phone) VALUES ('$Director_Name','$Director_id','$Gender','$Director_Email','$phone_code','$Director_phone')";
if($conn->query($sql)===TRUE){
echo  " ";
}else{
echo "Error:" ,$sql,"<br>",$conn->error;
}
$sql = "SELECT  Director_Name,Director_id,Gender,phone_code,Director_phone FROM  krss";
     $result = ($conn->query($sql));
	 if ($result->num_rows > 0)
	 {
		 echo "<table>";
		 while($row = $result->fetch_assoc()){
			 echo "<tr><td> Director_Name: " .$row["Director_Name"]."</td><td> Director_id: ".$row["Director_id"]."</td> <td> Gender: ".$row["Gender"]."</td><td> phone_code: ".$row["phone_code"]."</td><td> Director_phone: ".$row["Director_phone"]."</td></tr>";
			
		 }			
		 echo "</table>";
		 }else{
			 echo " 0 results";
		      }
		 
	 }
$conn->close();

?>
</html>