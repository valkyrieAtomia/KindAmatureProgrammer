<!DOCTYPE html>
<html>
<head>
<head><title>fetch data from Database</title>
<style>
   body{
         background:#8e95a5;
         margin:0;
}
.button {
  background-color: #DCDCDC;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button1 {width:250px;}
</style>
</head>
<body >
<h1><marquee bgcolor="sky blue">WELCOME TO MOVIES DATABASE SYSTEM
</marquee></h1>
<center><img src="databaseimage.jpg" height="500" width="1550">
</center>
<center><ul>
    <button class="button button1"><a href ="home.php">Home</a></button>                  
    <button class="button button1"><a href ="actor3.php">Actor</a></button>   
	<button class="button button1"><a href ="Director3.php">Director</a></button>
    <button class="button button1"><a href ="movie3.php">movie</a></button></li>
    <button class="button button1"><a href ="feedback3.php">feedback</a></button>
     <button class="button button1"><a href ="gellary.html">Gallery</a></button>
    <button class="button button1"><a href ="about.html">about</a></button>      

	
     
   </ul>
   </center>
 
   </body>
   </html>