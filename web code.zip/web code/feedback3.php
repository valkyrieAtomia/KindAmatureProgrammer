<?php
if($_SERVER['REQUEST_METHOD']==='GET'){
$servername="localhost";
$username="root";
$password="";
$dbname="soma";
}
$conn = new mysqli ($servername,$username,$password,$dbname); 
//if ($conn->connect_error){
//die("connection failed,$conn->connect_error");
//}
//echo "";
$sql = "SELECT  * FROM  feedback";
     $result = ($conn->query($sql));
	// if ($result->num_rows > 0)
	 
	?>
	<!DOCTYPE html>
<html>
<head>
<title>
<head>fetch data from Database</head>
</title>
<body >
<table align="center" border="1px" style="width:800px; line-height:40px;">
	<tr>
			<th colspan="4"><h2>Feedback</h2></th>
	</tr>
        <t>	
			<th>Movie_title</th>
			<th>Movie_id</th>
			<th>Movie_language</th>
			<th>Movie_Rating</th>
			
	    </t>
<?php
while($rows = $result->fetch_assoc())
{
	?>

	<tr>
     <td><?php echo $rows["Movie_title"]; ?></td>                                                                                                                                                                                                                                             
	 <td><?php echo $rows['Movie_id'];?></td>
	 <td><?php echo $rows['Movie_language'];?></td>
	 <td><?php echo $rows['Movie_Rating'];?></td>
	 
	 
	 </tr>
	 
	  
<?php
}
?>
</table>
</body>
</html>