<?php
if($_SERVER['REQUEST_METHOD']==='GET'){
$servername="localhost";
$username="root";
$password="";
$dbname="soma";
}
$conn = new mysqli ($servername,$username,$password,$dbname); 
//if ($conn->connect_error){
//die("connection failed,$conn->connect_error");
//}
//echo "";
$sql = "SELECT  * FROM  krss";
     $result = ($conn->query($sql));
	// if ($result->num_rows > 0)
	 
	?>
	<!DOCTYPE html>
<html>
<head>
<title>
<head>fetch data from Database</head>
</title>
<body >
<table align="center" border="1px" style="width:800px; line-height:40px;">
	<tr>
			<th colspan="6"><h2>Director details</h2></th>
	</tr>
        <t>	
			<th>Director_Name</th>
			<th>Director_id</th>
			<th>Gender</th>
			<th>Director_Email</th>
			<th>Phone_code</th>
			<th>Director_phone</th>
	    </t>
<?php
while($rows = $result->fetch_assoc())
{
	?>

	<tr>
     <td><?php echo $rows["Director_Name"]; ?></td>                                                                                                                                                                                                                                             
	 <td><?php echo $rows['Director_id'];?></td>
	 <td><?php echo $rows['Gender'];?></td>
	 <td><?php echo $rows['Director_Email'];?></td>
	 <td><?php echo $rows['phone_code'];?></td>
	 <td><?php echo $rows['Director_phone'];?></td>
	 
	 </tr>
	 
	  
<?php
}
?>
</table>
</body>
</html>