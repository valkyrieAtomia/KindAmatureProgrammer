<!DOCTYPE html>
<html>
<head>
<title>
<head>fetch data from Database</head>
</title>
<body>
<table align="center" border="1px" style="width:800px; line-height:40px;">
	<tr>
			<th colspan="6"><h2>Actor details</h2></th>
	</tr>
        <t>	
			<th>Actor_Name</th>
			<th>Actor_id</th>
			<th>Gender</th>
			<th>Actor_Email</th>
			<th>Phone_code</th>
			<th>Actor_phone</th>
	    </t>
	
	
<?php
if($_SERVER['REQUEST_METHOD']==='GET'){
$servername="localhost";
$username="root";
$password="";
$dbname="soma";

$conn = new mysqli ($servername,$username,$password,$dbname); 
if ($conn->connect_error){
die("connection failed,$conn->connect_error");
}
echo "";
$sql = "SELECT  * FROM  krs";
     $result = ($conn->query($sql));
	 if ($result->num_rows > 0)
	 {
		 echo "<table>";
		 while($row = $result->fetch_assoc()){
	
			echo "<tr>
			<td> Actor_Name: " .$row["Actor_Name"]."</td>
			<td> Actor_id: ".$row["Actor_id"]."</td>
			<td> Gender: ".$row["Gender"]."</td>
			<td> Actor_Email: ".$row["Actor_Email"]."</td>
			<td> phone_code: ".$row["phone_code"]."</td>
			<td> Actor_phone: ".$row["Actor_phone"]."</td>
			</tr>";
			
		 }			
		 echo "</table>";
		 }else{
			 echo " 0 results";
		      }
		 
	 }
//$conn->close();
?>