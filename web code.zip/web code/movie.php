<html>
<head>
<title>movies</title>
<style> 
input[type=text]{
  width: 25%;
  padding: 10px 10px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
input[type=email]{
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
input[type=phone]{
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 1px  ;
  border-radius: 4px;
}
select {
  width: 10%;
  padding: 12px 20px;
  border: none;
  margin: 8px 0;
  border-radius: 1px;
  background-color: ;
}
input[type=button], input[type=submit], input[type=reset] ,input[type=button]{
  background-color: #817F7F;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 2px 1px;
  cursor: pointer;
}
.button {
  background-color: #8e95a5;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head><h1>
<marquee bgcolor="sky blue">MOVIE DATABASE SYSTEM</marquee></h1>


<font size="6"><h2>Movies</h2></font>
<script>
	var i = 0;
	var images = [];
	var time = 2000;
    images[0] = '137.jpg';
	images[1] = '138.jpg';
	images[2] = '139.jpg';
	 images[3] = '140.jpg';
	  images[4] = '141.jpg';
	   images[5] = '142.jpg'; 
	    images[6]='106.jpg';
		 images[7] = '107.jpg';
		  images[8] = '108.jpg';
		   images[9] = '112.jpg';
		    images[10] = '114.jpg';
			
	function changeImg(){
		document.slide.src = images[i];

		if(i < images.length - 1){
			i++;
		} else {
			i = 0;
		}

		setTimeout("changeImg()", time);
	}

	window.onload = changeImg;

</script>

<center><img name="slide" width="1550" height="660"></center>
<br><br>


<body style="background-color:#8e95a5 ;"><br><br>
<form action="movie1.php" method="POST"><font size="5">

<b>Movie_title:<input name="Movie_title"type="text" value="" placeholder="Movie_title"><br><br>
Movie_id:<input name="Movie_id" type="text" value="" placeholder="movie_id"><br>
<br>
Release_Date :<label>Date:</label>
			 <input  name="Release_Date" type="date"><br><br>
			 
</select>
Movie_language:
<select name="Movie_language">
    <option selected hidden value="">language</option>
	<option value="english">english</option>
	<option value="Hindi">Hindi</option>
	<option value="kannada">kannada</option>
	<option value="telagu">telagu</option>
	<option value="tamil">tamil</option>
</select>
<br>
<br><input type="submit" value="submit">
<input type="Reset" value="Reset">
<button class="button"><a href ="home.php">Home</a></button>
</font>
</body>
</html>